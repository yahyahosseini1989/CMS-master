import React from 'react';
import Layout from './../Layout/Layout'
const About = () => {
    return (
        <>
            <Layout>
                <h2>
                    About us
                </h2>
            </Layout>
        </>
    );
}
export default About;