import React from 'react'
import Layout from './../Layout/Layout'

const Contact = () => {
    return (
        <>
            <Layout>
                <h2>
                    Contact us
                </h2>
            </Layout>
        </>
    );
}

export default Contact;